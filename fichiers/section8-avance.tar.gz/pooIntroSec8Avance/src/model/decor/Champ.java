package model.decor;

import java.awt.Point;

public class Champ extends Decor {

	public Champ(Point p) {
		super(p);
		// TODO Auto-generated constructor stub
	}

}
